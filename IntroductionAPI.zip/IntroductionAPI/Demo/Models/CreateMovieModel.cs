﻿namespace Demo.Models
{
    public class CreateMovieModel
    {

        public string Name { get; set; }
        public string Description { get; set; }

        public List<String> Films { get; set; }
    }
}
