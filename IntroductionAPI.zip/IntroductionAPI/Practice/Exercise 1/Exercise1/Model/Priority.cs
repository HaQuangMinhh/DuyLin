﻿namespace Exercise1.Model
{
    public enum Priority
    {
        Low, Medium, High
    }
}
