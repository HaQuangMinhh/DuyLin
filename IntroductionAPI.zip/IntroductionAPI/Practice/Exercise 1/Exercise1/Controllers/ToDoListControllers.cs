﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Exercise1.Model;
using System.Data;
using System.Globalization;
using System.Diagnostics;
using Microsoft.OpenApi.Validations;

namespace Exercise1.Controllers
{
    [Route("api/todos/[controller]")]
    [ApiController]

    public class ToDoListControllers : ControllerBase
    {
        private readonly IMongoCollection<ToDoItem> _todoCollection;

        public ToDoListControllers() {
            string connectionString = "mongodb://localhost:27017";
            var client = new MongoClient(connectionString);
            var database = client.GetDatabase("YourDatabaseName");
            _todoCollection = database.GetCollection<ToDoItem>("ToDoItem"); 
        }

        [HttpGet("GetAllItems")]
        public async Task<IActionResult> GetAllToDoItems( Dictionary<string,string> filters ) { 
            
            // Truy van
            var allItems = await _todoCollection.Find( _ => true ).ToListAsync();

            var result = allItems.Select(item => new
            {
                item.Title,
                item.Description,
                item.IsCompleted,
                item.Priority,
                DueDate = item.DueDate.ToString("yyyy-MM-dd HH:mm"),  // Định dạng lại thời gian thành chuỗi theo định dạng mong muốn
                item.Tags,
                item.EstimatedDuration,

                //item.CreateAt   : Cái này là hiện đúng như dưới mongoDB
                CreateAt = item.CreateAt.ToString("yyyy-MM-dd HH:mm"),
            }).ToList();


            return Ok(result);
        }

        // Filter : Get adavanced
        [HttpGet("SearchByTags")]
        public async Task<IActionResult> SearchByTags( [FromQuery] string tag ) {
            // User truyền vào 1 List --> Tìm 

            // Check empty 
            if ( string.IsNullOrEmpty(tag) ) {
                return BadRequest(" Tags parameter is required");
            }

            // split each tag by , + bỏ khoảng trống
            var tagList = tag.Split(',').Select(tag => tag.Trim().ToLower() ).ToList() ;
            
            // Filter to find a tag in list
            var filterTag = Builders<ToDoItem>.Filter.AnyIn( x => x.Tags , tagList);  //AnyIn : tồn tại

            // Truy van 
            var todoTag = await _todoCollection.Find(filterTag).ToListAsync();

            // Check if không tìm thấy 
            if ( todoTag == null || !todoTag.Any() ) {
                return NotFound("No tag found matching in the list"); 
            }

            return Ok(todoTag);
        }

        [HttpGet("SearchDueDate")]  // Lọc các todo làm trong khoảng đó 
        public async Task<IActionResult> GetTasksRangeByDueDate ( DateTime? startDate , DateTime? endDate ) {

            // check logic  ( user không input any date
            if ( startDate == null && endDate == null ) { 
                return BadRequest("You must input at least one of startDate or endDate");
            }

            // Use Filter Builder to create condition 
            var filterDate = Builders<ToDoItem>.Filter.Empty;   // Cho trống

            // check condition only input 1 or 2
            if ( startDate.HasValue ) {      // Dùng toán tử gán kết hợp to match condition
                filterDate &= Builders<ToDoItem>.Filter.Gte( x => x.DueDate, startDate.Value );
            }

            if ( endDate.HasValue ) {
                filterDate &= Builders<ToDoItem>.Filter.Lte(x => x.DueDate , endDate.Value);
            }


            // Search các todo có trong khoảng time  ( hạn chế dùng ) 
            var todos = await _todoCollection
                .Find(filterDate)   // Use Filter here
                .SortBy(x => x.DueDate).ToListAsync();

            if (!todos.Any())
            {
                return NotFound("No tasks found within the date range");
            }

            return Ok(todos);

        }

        // Lọc các Duedate : Use only a string  (ver2)
        [HttpGet("SearchDueDateByString")]  // Lọc các todo làm trong khoảng đó 
        public async Task<IActionResult> GetTasksRangeByDueDateByString (String range)
        {

            // Case1 : Hk input String 
            if (String.IsNullOrEmpty(range) ) {
                return BadRequest("You must input at least ");
            }

            // Khai báo startDate and endDate = null
            DateTime? startDate = null; 
            DateTime? endDate = null;   

            // Xử lí chuỗi string
            var param = range.Split(',');

            if (param.Length == 2)
            {
                var condition3 = string.IsNullOrWhiteSpace(param[0]);
                var condition4 = string.IsNullOrWhiteSpace(param[1]);
                if (!condition3 && !condition4)
                {
                    // Change String to DateTime
                    var condition1 = DateTime.TryParse(param[0], out DateTime start);
                    var condition2 = DateTime.TryParse(param[1], out DateTime end);

                    if (condition1 && condition2)
                    {
                        startDate = start;
                        endDate = end;
                    }
                    else
                    {
                        return BadRequest("Invalid format. Please use yyyy/mm/dd");
                    }

                }
                else { 
                
                }
                

                // Case 1 : Only have endDate ( dấu phẩy ) 
            } else if (param.Length == 2 && string.IsNullOrWhiteSpace(param[0])) {
                var condition2 = DateTime.TryParse(param[1], out DateTime end);
                if (condition2)
                {
                    endDate = end;
                }
                else
                {
                    return BadRequest("Invalid format. Please use yyyy/mm/dd");
                }

                // Case 2 : Only have startDate
            } else if (param.Length == 1) {

                var condition1 = DateTime.TryParse(param[0], out DateTime start);

                if (condition1)
                {
                    startDate = start;
                }
                else {
                    return BadRequest("Invalid format. Please use yyyy/mm/dd");
                } 

            } else if ( param.Length == 0 ) {

                return BadRequest("Please input at least one date");
            }

            else {
                return BadRequest("Invalid date range. Input two dates by a separate comma");
            }

            

            // check logic  ( user không input any date )
            if (startDate == null && endDate == null)
            {
                return BadRequest("You must input at least one of startDate or endDate");
            }

            // Use Filter Builder to create condition 
            var filterDate = Builders<ToDoItem>.Filter.Empty;   // Cho trống

            // check condition only input 1 or 2
            if (startDate.HasValue)
            {      // Dùng toán tử gán kết hợp to match condition
                filterDate &= Builders<ToDoItem>.Filter.Gte(x => x.DueDate, startDate.Value);
            }

            if (endDate.HasValue)
            {
                filterDate &= Builders<ToDoItem>.Filter.Lte(x => x.DueDate, endDate.Value);
            }


            // Search các todo có trong khoảng time  ( hạn chế dùng ) 
            var todos = await _todoCollection
                .Find(filterDate)   // Use Filter here
                .SortBy(x => x.DueDate).ToListAsync();

            if (!todos.Any())
            {
                return NotFound("No tasks found within the date range");
            }

            return Ok(todos);

        }


        [HttpPost]
        public async Task<IActionResult> CreateItems(CreateToDoItem newItem) {

            // Use Enum.tryParse to change 

            // Convert String to DateTime
            DateTime convertedDueDate;
            string expectedFormat = "yyyy-MM-dd HH-mm";       // format giờ - phút

            if ( ! DateTime.TryParseExact(newItem.DueDate, expectedFormat,
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out convertedDueDate))
            {
                // Error kia
                return BadRequest("Invalid Due Date Format, Please use :yyyy-MM-dd HH-mm");
            }

            // Chỉnh múi giờ Việt Nam
            TimeZoneInfo vietnamTimeZone = TimeZoneInfo.FindSystemTimeZoneById("SE Asia Standard Time");

            // Chuyển đổi thời gian sang múi giờ Việt Nam
            DateTime vietnamTime = TimeZoneInfo.ConvertTime(convertedDueDate, vietnamTimeZone);

            // check if the due date in the future
            if ( ! DateValidator.FutureDate(vietnamTime)  ) {
                return BadRequest("Due date must be in the future");
            }


            var itemData = new ToDoItem
            {
                Title = newItem.Title,
                Description = newItem.Description,
                IsCompleted = newItem.IsCompleted,
                Priority = newItem.Priority, // nhận vào số : Conver String to Enum --> Create 
                DueDate = vietnamTime,     // DateOnly or DateTime  
                Tags = newItem.Tags,
                EstimatedDuration = newItem.EstimatedDuration,

                CreateAt = DateTime.Now,
            };

            await _todoCollection.InsertOneAsync(itemData);

            return Ok(itemData);

 
        }

        [HttpGet("overdue")]
        public async Task<IActionResult> GetOverDueItems() { 
            
            // Get today time
            var currentDate = DateTime.Now;

            // Truy van MongoDb : Filter
            var overdueTodos = await _todoCollection.Find(v => v.DueDate < currentDate && !v.IsCompleted).ToListAsync();

            return Ok( overdueTodos );
       
        }

        [HttpPost("CreateTodoItem3")]
        public async Task<IActionResult> CreateTodoItem3 (CreateToDoItem newItem) {

            // Change DueDate from String to DateTime
            if (!DateTime.TryParseExact(newItem.DueDate, "yyyy-MM-dd HH-mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dueDate))
            {
                return BadRequest("Due Date must be in the format yyyy-MM-dd");
            }

            // check DueDue hk dc trong past
            if (  dueDate <= DateTime.Now)
            {
                return BadRequest("Due Date cannot be in the past");
            }

            // If Priority is “High”, EstimatedDuration must be at least 1 hour.
            if ( newItem.Priority == Priority.High && newItem.EstimatedDuration < 60 ) { 
                return BadRequest(" Priority is “High”, EstimatedDuration must be at least 1 hour. ");
            }

            // Check title is unique 
            var uniqueTitle = await _todoCollection.Find(x => x.Title.ToLower() == newItem.Title.ToLower()).FirstOrDefaultAsync();
            if ( uniqueTitle != null ) {
                return BadRequest("Title must be unique"); 
            }

            // Create moi todo
            var todoItem = new ToDoItem
            {
                Title = newItem.Title,
                Description = newItem.Description,
                IsCompleted = newItem.IsCompleted,
                Priority = newItem.Priority,
                DueDate = dueDate,
                Tags = newItem.Tags,

                EstimatedDuration = newItem.EstimatedDuration,

                CreateAt = DateTime.Now,
            };

            // truy vấn 
            await _todoCollection.InsertOneAsync(todoItem);

            return Ok(todoItem);

        }








    }
}
