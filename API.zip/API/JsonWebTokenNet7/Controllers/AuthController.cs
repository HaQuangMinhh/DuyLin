﻿using JsonWebTokenNet7.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace JsonWebTokenNet7.Controllers
{
    [Route("Api/[controller]")]
    [ApiController]

    public class AuthController : Controller
    {
        public static User user = new User();
        private readonly IConfiguration _configuration ;

        public AuthController( IConfiguration configuration ) { 
            _configuration = configuration;
        }

        [HttpPost("register")]
        public ActionResult<User> Register( UserDto request ) { 

            string passwordHash = BCrypt.Net.BCrypt.HashPassword(request.Password);
            
            user.Username = request.Username;
            user.PasswordHash = passwordHash;
            user.Role = request.Role; 

            return Ok( user );

        }

        [HttpPost("login")]
        public ActionResult<User> Login( LoginDto request ) {
            if ( user.Username != request.Username ) {
                return BadRequest("Not found");
            }

            if ( ! BCrypt.Net.BCrypt.Verify(request.Password , user.PasswordHash ) ) {
                return BadRequest("Wrong Password"); 
            }

            string token = CreateToken(user);

            return Ok( token );
        }

        private string CreateToken( User user ) {

            List<Claim> claims = new List<Claim> {
                new Claim ( ClaimTypes.Name , user.Username ),
                // Create additionally rule of an user
                new Claim ( ClaimTypes.Role , user.Role ),


                new Claim ( ClaimTypes.Version , "1" )
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(  // import lib : using Microsoft.IdentityModel.Tokens;
                _configuration.GetSection("AppSettings:Token").Value!  
             ));
            // rồi sang Appsetting

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(
                    claims : claims,
                    expires : DateTime.Now.AddDays(1),
                    signingCredentials : creds
                );

            var jwt = new JwtSecurityTokenHandler().WriteToken(token);

            return jwt;
        }

        // Need : thêm role vào đó
        // 

        
    }
}
